$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/java/features/bookdepository.feature");
formatter.feature({
  "line": 1,
  "name": "Trabajo Practico Final Curso Automation II.",
  "description": "",
  "id": "trabajo-practico-final-curso-automation-ii.",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 3,
  "name": "Search a Book",
  "description": "",
  "id": "trabajo-practico-final-curso-automation-ii.;search-a-book",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "I enter a \u003csearchword\u003e",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "I press Search button",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "I sort result by \u003corderBy\u003e",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "I click on first element",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Book page must be shown",
  "keyword": "Then "
});
formatter.examples({
  "line": 11,
  "name": "",
  "description": "",
  "id": "trabajo-practico-final-curso-automation-ii.;search-a-book;",
  "rows": [
    {
      "cells": [
        "searchword",
        "orderBy"
      ],
      "line": 13,
      "id": "trabajo-practico-final-curso-automation-ii.;search-a-book;;1"
    },
    {
      "cells": [
        "Sailor moon tomo 7",
        "price_low_high"
      ],
      "line": 14,
      "id": "trabajo-practico-final-curso-automation-ii.;search-a-book;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 32613349261,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Search a Book",
  "description": "",
  "id": "trabajo-practico-final-curso-automation-ii.;search-a-book;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "I enter a Sailor moon tomo 7",
  "matchedColumns": [
    0
  ],
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "I press Search button",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "I sort result by price_low_high",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "I click on first element",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Book page must be shown",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "Sailor moon tomo 7",
      "offset": 10
    }
  ],
  "location": "SearchBook.i_enter_a(String)"
});
formatter.result({
  "duration": 2249130391,
  "status": "passed"
});
formatter.match({
  "location": "SearchBook.i_press_search_button()"
});
formatter.result({
  "duration": 4462480064,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "price_low_high",
      "offset": 17
    }
  ],
  "location": "OrderBook.i_sort_result_by(String)"
});
formatter.result({
  "duration": 3699332270,
  "status": "passed"
});
formatter.match({
  "location": "OrderBook.i_click_on_first_element()"
});
formatter.result({
  "duration": 2011418121,
  "status": "passed"
});
formatter.match({
  "location": "OrderBook.book_page_on_first_element()"
});
formatter.result({
  "duration": 1603077757,
  "status": "passed"
});
formatter.write("--------------------------------------------------------------");
formatter.write("ID: trabajo-practico-final-curso-automation-ii.;search-a-book;;2");
formatter.write("Name : Search a Book");
formatter.write("Status : passed");
formatter.write("Price: ARS$284,90");
formatter.embedding("image/png", "embedded0.png");
formatter.write("--------------------------------------------------------------");
